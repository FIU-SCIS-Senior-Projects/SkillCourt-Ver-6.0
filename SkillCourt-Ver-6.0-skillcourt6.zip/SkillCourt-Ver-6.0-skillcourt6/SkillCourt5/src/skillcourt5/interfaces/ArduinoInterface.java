package skillcourt5.interfaces;

/**
 * Created by pedrocarrillo on 9/21/16.
 */
public interface ArduinoInterface {

    void receivedData(int data);

}
