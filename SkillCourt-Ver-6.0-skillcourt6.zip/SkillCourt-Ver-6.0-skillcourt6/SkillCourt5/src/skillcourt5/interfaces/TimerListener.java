package skillcourt5.interfaces;


public interface TimerListener {

    void onSecond(int time);
    void onStop();

}
