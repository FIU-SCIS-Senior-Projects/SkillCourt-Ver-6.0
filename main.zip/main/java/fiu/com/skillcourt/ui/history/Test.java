package fiu.com.skillcourt.ui.history;

/**
 * Created by April on 10/26/2016.
 */

public class Test {

    String beat_timer;
    int hit_counter;
}
