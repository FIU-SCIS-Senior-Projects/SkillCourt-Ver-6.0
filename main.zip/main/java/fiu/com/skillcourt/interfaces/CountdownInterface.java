package fiu.com.skillcourt.interfaces;

/**
 * Created by pedrocarrillo on 9/22/16.
 */

public interface CountdownInterface {

    void onTick(long millisUntilFinished);
    void onFinish();

}
