package fiu.com.skillcourt.interfaces;

import android.support.v7.widget.Toolbar;

/**
 * Created by pedrocarrillo on 9/10/16.
 */

public interface FragmentListener {

    void closeActivity();

}
